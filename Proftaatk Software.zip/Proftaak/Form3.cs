﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using Proftaak_Software;

namespace TxtOutput
{
    public partial class Form3 : Form
    {
        Thread th;

        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                FolderBrowserDialog FBD = new FolderBrowserDialog();

                if (FBD.ShowDialog() == DialogResult.OK)
                {
                    listBox1.Items.Clear();
                    string[] files = Directory.GetFiles(FBD.SelectedPath);
                    string[] dirs = Directory.GetDirectories(FBD.SelectedPath);

                    foreach (string file in files)
                    {
                        listBox1.Items.Add(file);
                    }
                    foreach (string dir in dirs)
                    {
                        listBox1.Items.Add(dir);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = File.ReadAllText(Convert.ToString(listBox1.SelectedItem));
            MessageBox.Show(text);
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void opennewform(object obj)
        {
            System.Windows.Forms.Application.Run(new Form2());
        }

    }
}
